﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace xzero
{
    public partial class Players : Form
    {
        int c = 0;
        string nume = File.ReadAllText(@"E:\Harangus Dan\C#\xzero\xzero\bin\Debug\players.txt");

        public Players()
        {
            InitializeComponent();
        }

        private void done_Click(object sender, EventArgs e)
        {
            if (c == 0)
            {
                File.WriteAllText(@"E:\Harangus Dan\C#\xzero\xzero\bin\Debug\players.txt", textBox1.Text + " ");
                player.Text = "Player 2:";
                textBox1.Text = "";
                c++;
            }
            else
            {
                File.WriteAllText(@"E:\Harangus Dan\C#\xzero\xzero\bin\Debug\players.txt", textBox1.Text + " ");
                frmXO fXO = new frmXO();
                fXO.Show();
                player.Hide();
            }
            c++;
        }
    }
}
