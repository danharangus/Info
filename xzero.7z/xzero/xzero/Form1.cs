﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xzero
{
    public partial class frmXO : Form
    {
        int click = 0, scorX = 0, scorO = 0,i;

        private string corect()
        {
            if (label1.Text == label2.Text && label2.Text == label3.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label4.Text == label5.Text && label5.Text == label6.Text && label4.Text != "") 
            {
                return label4.Text;
            }
            if (label7.Text == label8.Text && label8.Text == label9.Text && label7.Text != "") 
            {
                return label7.Text;
            }
            if (label1.Text == label4.Text && label4.Text == label7.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label2.Text == label5.Text && label5.Text == label8.Text && label2.Text != "") 
            {
                return label2.Text;
            }
            if (label3.Text == label6.Text && label6.Text == label9.Text && label3.Text != "") 
            {
                return label3.Text;
            }
            if (label1.Text == label5.Text && label5.Text == label9.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label3.Text == label5.Text && label5.Text == label7.Text && label3.Text != "") 
            {
                return label3.Text;
            }
            return "";

        }

        public frmXO()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label lbl1 = (sender as Label);
            if (lbl1.Text != "")
            {
                return;
            }

            click++;


            if (click % 2 == 1)
            {
                lbl1.Text = "X";
                turn.Text = "O";
            }
            else
            {
                lbl1.Text = "O";
                turn.Text = "X";
            }


            if (corect() == "X")
            {
                MessageBox.Show("X a castigat!");
                scorX++;
                ValSX.Text = scorX.ToString();
                for (i = 1; i <= 9; i++)
                {
                    (this.Controls["label" + i.ToString()] as Label).Text = "";
                }
                click = 0;
            }
            else if (corect() == "O")
            {
                MessageBox.Show("O a castigat!");
                scorO++;
                ValSO.Text = scorO.ToString();
                for (i = 1; i <= 9; i++)
                {
                    (this.Controls["label" + i.ToString()] as Label).Text = "";
                }
                click = 0;
            }
            else
            {
                if (click == 9)
                {
                    MessageBox.Show("Remiza!");
                    for (i = 1; i <= 9; i++)
                    {
                        (this.Controls["label" + i.ToString()] as Label).Text = "";
                    }
                    click = 0;

                }
            }
        }

    }
}
