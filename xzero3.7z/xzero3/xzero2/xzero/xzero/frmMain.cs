﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xzero
{
    public partial class frmMain : Form
    {
      
        public frmMain()
        {
            InitializeComponent();
        }

        public frmXO fXO;
        public Players players;

        private void xOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fXO != null)
            {
                MessageBox.Show("Error: Only one instance of the game can run at a time.");
            }
           else if (players == null)
            {
                 players = new Players();
                 players.MdiParent = this;
                 players.Show();
             }
            
        }

        private void mainfrm_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
