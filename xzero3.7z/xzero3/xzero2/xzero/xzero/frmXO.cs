﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace xzero
{
    public partial class frmXO : Form
    {
        int click = 0, scorX = 0, scorO = 0,i;

        private void frmXO_Load(object sender, EventArgs e)
        {
            turn.Text = Players.player1;
            NumeO.Text = Players.player2;
            Numex.Text = Players.player1;
        }

        private void frmXO_FormClosed(object sender, FormClosedEventArgs e)
        {
           (this.MdiParent as frmMain).fXO = null;

        }

        private string corect()
        {
            if (label1.Text == label2.Text && label2.Text == label3.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label4.Text == label5.Text && label5.Text == label6.Text && label4.Text != "") 
            {
                return label4.Text;
            }
            if (label7.Text == label8.Text && label8.Text == label9.Text && label7.Text != "") 
            {
                return label7.Text;
            }
            if (label1.Text == label4.Text && label4.Text == label7.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label2.Text == label5.Text && label5.Text == label8.Text && label2.Text != "") 
            {
                return label2.Text;
            }
            if (label3.Text == label6.Text && label6.Text == label9.Text && label3.Text != "") 
            {
                return label3.Text;
            }
            if (label1.Text == label5.Text && label5.Text == label9.Text && label1.Text != "") 
            {
                return label1.Text;
            }
            if (label3.Text == label5.Text && label5.Text == label7.Text && label3.Text != "") 
            {
                return label3.Text;
            }
            return "";

        }

        public frmXO()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label lbl1 = (sender as Label);
            if (lbl1.Text != "")
            {
                return;
            }

            click++;


            if (click % 2 == 1)
            {
                lbl1.Text = "X";
                turn.Text = Players.player2;
            }
            else
            {
                lbl1.Text = "O";
                turn.Text = Players.player1;
            }


            if (corect() == "X")
            {
                MessageBox.Show(Players.player1 + " a castigat!");
                scorX++;
                ValSX.Text = scorX.ToString();
                for (i = 1; i <= 9; i++)
                {
                    (this.Controls["label" + i.ToString()] as Label).Text = "";
                }
                turn.Text = Players.player2;
                click = 0;
            }
            else if (corect() == "O")
            {
                MessageBox.Show(Players.player2 + " a castigat!");
                scorO++;
                ValSO.Text = scorO.ToString();
                for (i = 1; i <= 9; i++)
                {
                    (this.Controls["label" + i.ToString()] as Label).Text = "";
                }
                click = 0;
            }
            else
            {
                if (click == 9)
                {
                    MessageBox.Show("Remiza!");
                    for (i = 1; i <= 9; i++)
                    {
                        (this.Controls["label" + i.ToString()] as Label).Text = "";
                    }
                    turn.Text = Players.player1;
                    click = 0;

                }
            }
        }

    }
}
