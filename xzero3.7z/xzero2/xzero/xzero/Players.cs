﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xzero
{
    public partial class Players : Form
    {
        int c = 0;

        public static string player1, player2;

         

        public Players()
        {
            InitializeComponent();
        }

        private void done_Click(object sender, EventArgs e)
        {
            if (c == 0)
            {
                if (textBox1.Text.Length > 4)
                {
                    MessageBox.Show("Error: The name is too long. It may contain a maximum of 4 characters.");
                    textBox1.Text = "";
                }
                else
                {
                    player1 = textBox1.Text;
                    player.Text = "Player 2:";
                    textBox1.Text = "";
                    c++;
                }
            }
            else
            {
                if (textBox1.Text.Length > 4)
                {
                    MessageBox.Show("Error: The name is too long. It may contain a maximum of 4 characters.");
                    textBox1.Text = "";
                }
                else
                {
                    player2 = textBox1.Text;
                    frmXO fXO = new frmXO();
                    fXO.Show();
                    this.Close();
                }
            }
        }
    }
}
