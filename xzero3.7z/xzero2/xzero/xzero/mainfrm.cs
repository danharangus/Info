﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xzero
{
    public partial class mainfrm : Form
    {
      
        public mainfrm()
        {
            InitializeComponent();
        }

        public frmXO fXO;
        public Players players;

        private void xOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(players == null)
            {
                players = new Players();
                players.MdiParent = this;
                players.Show();
            }
        }
    }
}
